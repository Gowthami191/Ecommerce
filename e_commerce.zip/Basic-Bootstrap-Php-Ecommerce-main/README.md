# Basic-Bootstrap-Php-Ecommerce

![𝚅𝚒𝚜𝚒𝚝𝚘𝚛𝚜](https://visitor-badge.laobi.icu/badge?page_id=ajayrandhawa.Basic-Bootstrap-Php-Ecommerce&title=Visitor )

Basic HTML, BOOTSTRAP, PHP Ecommerce Site. Just Basic Functionality with login, register, product listing, cart management, checkout. It comes with MySql database.

## Features: 

1. Login
2. Register
3. Product Listing
4. Cart Manage
5. Delivery Address Page
6. CheckOut

<img src="sc.png" />

Feel Free To Contribute :)
