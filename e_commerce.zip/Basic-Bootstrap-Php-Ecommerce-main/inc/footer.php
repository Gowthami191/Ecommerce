<footer class="container-fluid p-4 clearfix">
    <div class="container clearfix">
        <a class="float-left text-dark" href="terms.php">Terms & Conditions</a>
        <a class="float-left ml-3 text-dark" href="terms.php">Privacy Policy</a>
        <p class="float-right">Copyright © 2020 |  Made in ❤️ <b>Open Source</b> </p>
    </div>  
</footer>